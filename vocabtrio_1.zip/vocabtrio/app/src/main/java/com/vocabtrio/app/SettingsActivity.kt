package com.vocabtrio.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Vibrator
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val switchHaptics = findViewById<MaterialSwitch>(R.id.switchHaptics)
        val btnThemeToggle = findViewById<Button>(R.id.btnThemeToggle)
        val btnAbout = findViewById<Button>(R.id.btnAbout)

        val themePrefs = getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE)
        val hapticsPrefs = getSharedPreferences("HapticsPrefs", Context.MODE_PRIVATE)

        // Haptics Logic
        switchHaptics.isChecked = hapticsPrefs.getBoolean("hapticsEnabled", true)
        switchHaptics.setOnCheckedChangeListener { _, isChecked ->
            hapticsPrefs.edit().putBoolean("hapticsEnabled", isChecked).apply()
            if (isChecked) {
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(50)
            }
        }

        // Theme Logic
        btnThemeToggle.setOnClickListener {
            val isDarkMode = themePrefs.getBoolean("isDarkMode", false)
            if (isDarkMode) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                themePrefs.edit().putBoolean("isDarkMode", false).apply()
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                themePrefs.edit().putBoolean("isDarkMode", true).apply()
            }
            recreate()
        }

        // About & GitHub Logic
        btnAbout.setOnClickListener {
            val versionName = try {
                packageManager.getPackageInfo(packageName, 0).versionName
            } catch (e: Exception) {
                "1.0"
            }

            AlertDialog.Builder(this)
                .setTitle("About Vocabtrio")
                .setMessage("Vocabtrio v$versionName\n\nA fast, modern, trilingual dictionary app supporting English, Hindi, and Odia. Built entirely on mobile using Code on the Go.\n\nWould you like to visit the GitHub repository?")
                .setPositiveButton("Visit GitHub") { _, _ ->
                    
                    // THE EXACT URL IS NOW HERE
                    val url = "https://github.com/asish-priyadarshan/Vocabtrio-" 
                    
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                }
                .setNegativeButton("Close", null)
                .show()
        }
    }
}