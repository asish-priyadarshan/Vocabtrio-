package com.vocabtrio.app

import android.app.Application
import com.google.android.material.color.DynamicColors

class VocabtrioApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // This forces the colors to load before the Splash Screen even starts
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}