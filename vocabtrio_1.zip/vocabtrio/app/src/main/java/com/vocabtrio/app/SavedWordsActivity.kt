package com.vocabtrio.app

import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SavedWordsActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var displayList: MutableList<String>
    private lateinit var rawSavedList: MutableList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saved)

        listView = findViewById(R.id.listViewSavedWords)
        val prefs = getSharedPreferences("SavedDict", Context.MODE_PRIVATE)
        val savedSet = prefs.getStringSet("words", mutableSetOf()) ?: mutableSetOf()
        
        rawSavedList = savedSet.toMutableList()
        displayList = rawSavedList.map { it.split("|")[0] }.toMutableList() 

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        listView.adapter = adapter

        listView.setOnItemLongClickListener { _, _, position, _ ->
            val wordToRemove = rawSavedList[position]
            AlertDialog.Builder(this)
                .setTitle("Remove Word")
                .setMessage("Do you want to remove '${displayList[position]}'?")
                .setPositiveButton("Yes") { _, _ ->
                    rawSavedList.removeAt(position)
                    displayList.removeAt(position)
                    adapter.notifyDataSetChanged()

                    val editor = prefs.edit()
                    editor.putStringSet("words", rawSavedList.toSet())
                    editor.apply()
                    Toast.makeText(this, "Removed", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("No", null)
                .show()
            true
        }
    }
}