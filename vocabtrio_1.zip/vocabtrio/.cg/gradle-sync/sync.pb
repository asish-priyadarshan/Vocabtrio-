
21/storage/emulated/0/CodeOnTheGoProjects/vocabtrio1794473746270"�
app/build.gradle.ktsF/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/app/build.gradle.kts� �����4*@9f6b9bbf05edecd4adf3bea54404a95412d4b08dd0d35055c6d9a99340065b5a"�
build.gradle.ktsB/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/build.gradle.kts� ���ל4*@894c92aa66d7ae56d21573617b028f15675252935e41e9fd8165c4b41cec3d37"�
gradle.propertiesC/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/gradle.properties�
 ���ל4*@194f9064020d41d27decd9e74375ff1459b75854f0d68f38e0375ca3b4f031b4"�
(gradle/wrapper/gradle-wrapper.propertiesZ/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/gradle/wrapper/gradle-wrapper.properties� ���ל4*@80dbd23007872ba453e1dcc698121d3c18d71e937a413f7543761a6d4ce93e40"�
settings.gradle.ktsE/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/settings.gradle.kts� ���ל4*@ad58acfb23a41ced7be60c6764d492d816725b49d1f95227dcb6516fb9102cd7*�
L/storage/emulated/0/CodeOnTheGoProjects/vocabtrio/.cg/gradle-sync/project.pb@c6f684b991af3c5f75ee08556dd69a176981467692d7efa9b0a0db24e71d9dc8