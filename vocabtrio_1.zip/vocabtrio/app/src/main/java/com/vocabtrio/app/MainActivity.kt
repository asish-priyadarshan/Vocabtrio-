package com.vocabtrio.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.widget.NestedScrollView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.DynamicColors
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.concurrent.thread

// Removed TextToSpeech.OnInitListener from the class declaration
class MainActivity : AppCompatActivity() {

    private lateinit var mainScrollView: NestedScrollView
    private lateinit var etSearch: EditText
    private lateinit var btnSearch: Button
    private lateinit var btnRandom: Button
    private lateinit var btnSave: Button
    private lateinit var btnViewSaved: Button
    private lateinit var btnSpeak: Button
    private lateinit var btnSpeakHindi: Button
    private lateinit var btnSpeakOdia: Button
    private lateinit var btnCopy: Button
    private lateinit var btnShare: Button
    private lateinit var btnClearHistory: Button
    private lateinit var btnSettings: Button
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var resultsLayout: LinearLayout
    private lateinit var chipGroupHistory: ChipGroup
    private lateinit var progressBar: ProgressBar
    
    private lateinit var tvWord: TextView
    private lateinit var tvPos: TextView
    private lateinit var tvDefinition: TextView
    private lateinit var tvExample: TextView
    private lateinit var tvSynonyms: TextView
    private lateinit var tvAntonyms: TextView
    private lateinit var tvHindi: TextView
    private lateinit var tvOdia: TextView

    private lateinit var ttsEnglish: TextToSpeech
    private lateinit var ttsHindi: TextToSpeech
    private lateinit var ttsOdia: TextToSpeech
    
    private var isEngReady = false
    private var isHinReady = false
    private var isOdiReady = false

    private var currentWord = ""
    private var currentDef = ""
    private var fullTextToShare = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        val sharedPreferences = getSharedPreferences("ThemePrefs", Context.MODE_PRIVATE)
        val isDarkMode = sharedPreferences.getBoolean("isDarkMode", false)
        
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        super.onCreate(savedInstanceState)
        DynamicColors.applyToActivityIfAvailable(this)
        setContentView(R.layout.activity_main)

        mainScrollView = findViewById(R.id.mainScrollView)
        etSearch = findViewById(R.id.etSearch)
        btnSearch = findViewById(R.id.btnSearch)
        btnRandom = findViewById(R.id.btnRandom)
        btnSave = findViewById(R.id.btnSave)
        btnViewSaved = findViewById(R.id.btnViewSaved)
        btnSpeak = findViewById(R.id.btnSpeak)
        btnSpeakHindi = findViewById(R.id.btnSpeakHindi)
        btnSpeakOdia = findViewById(R.id.btnSpeakOdia)
        btnCopy = findViewById(R.id.btnCopy)
        btnShare = findViewById(R.id.btnShare)
        btnClearHistory = findViewById(R.id.btnClearHistory)
        btnSettings = findViewById(R.id.btnSettings) 
        emptyStateLayout = findViewById(R.id.emptyStateLayout)
        resultsLayout = findViewById(R.id.resultsLayout)
        chipGroupHistory = findViewById(R.id.chipGroupHistory)
        progressBar = findViewById(R.id.progressBar)
        
        tvWord = findViewById(R.id.tvWord)
        tvPos = findViewById(R.id.tvPos)
        tvDefinition = findViewById(R.id.tvDefinition)
        tvExample = findViewById(R.id.tvExample)
        tvSynonyms = findViewById(R.id.tvSynonyms)
        tvAntonyms = findViewById(R.id.tvAntonyms)
        tvHindi = findViewById(R.id.tvHindi)
        tvOdia = findViewById(R.id.tvOdia)

        // INITIALIZE TTS FOR 3 LANGUAGES
        ttsEnglish = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) { ttsEnglish.language = Locale.US; isEngReady = true } }
        ttsHindi = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) { ttsHindi.language = Locale("hi", "IN"); isHinReady = true } }
        ttsOdia = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) { ttsOdia.language = Locale("or", "IN"); isOdiReady = true } }

        if (savedInstanceState != null) {
            tvWord.text = savedInstanceState.getString("word")
            tvPos.text = savedInstanceState.getString("pos")
            tvDefinition.text = savedInstanceState.getString("def")
            tvExample.text = savedInstanceState.getString("example")
            tvSynonyms.text = savedInstanceState.getString("syn")
            tvAntonyms.text = savedInstanceState.getString("ant")
            tvHindi.text = savedInstanceState.getString("hindi")
            tvOdia.text = savedInstanceState.getString("odia")
            currentWord = savedInstanceState.getString("currentWord") ?: ""
            currentDef = savedInstanceState.getString("currentDef") ?: ""
            fullTextToShare = savedInstanceState.getString("shareText") ?: ""
            resultsLayout.visibility = savedInstanceState.getInt("visibility", View.GONE)
            emptyStateLayout.visibility = savedInstanceState.getInt("emptyVis", View.VISIBLE)
        }

        btnSettings.setOnClickListener { performHapticFeedback(); startActivity(Intent(this, SettingsActivity::class.java)) }
        btnSearch.setOnClickListener { performHapticFeedback(); performSearch() }

        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { performHapticFeedback(); performSearch(); true } else { false }
        }

        btnRandom.setOnClickListener {
            performHapticFeedback()
            val randomWords = listOf("Serendipity", "Love", "Resilience", "Knowledge", "Beautiful", "Innovation", "Happy", "Ephemeral", "Water", "Time")
            etSearch.setText(randomWords.random())
            performSearch()
        }

        btnClearHistory.setOnClickListener {
            performHapticFeedback()
            getSharedPreferences("HistoryPrefs", Context.MODE_PRIVATE).edit().remove("history").apply()
            loadHistory()
            Toast.makeText(this, "History Cleared", Toast.LENGTH_SHORT).show()
        }

        btnSpeak.setOnClickListener {
            performHapticFeedback()
            if (isEngReady && currentWord.isNotEmpty()) ttsEnglish.speak(currentWord, TextToSpeech.QUEUE_FLUSH, null, "")
        }

        btnSpeakHindi.setOnClickListener {
            performHapticFeedback()
            val textToSpeak = tvHindi.text.toString().replace("Hindi: ", "")
            if (isHinReady && textToSpeak.isNotEmpty() && textToSpeak != "Not available") {
                ttsHindi.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "")
            } else if (!isHinReady) {
                Toast.makeText(this, "Hindi voice not installed on phone.", Toast.LENGTH_SHORT).show()
            }
        }

        btnSpeakOdia.setOnClickListener {
            performHapticFeedback()
            val textToSpeak = tvOdia.text.toString().replace("Odia: ", "")
            if (isOdiReady && textToSpeak.isNotEmpty() && textToSpeak != "Not available") {
                ttsOdia.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "")
            } else if (!isOdiReady) {
                Toast.makeText(this, "Odia voice not installed on phone.", Toast.LENGTH_SHORT).show()
            }
        }

        btnSave.setOnClickListener { performHapticFeedback(); saveWord() }
        btnViewSaved.setOnClickListener { performHapticFeedback(); startActivity(Intent(this, SavedWordsActivity::class.java)) }

        btnCopy.setOnClickListener {
            performHapticFeedback()
            if (fullTextToShare.isNotEmpty()) {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Vocabtrio", fullTextToShare))
                Toast.makeText(this, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
            }
        }

        btnShare.setOnClickListener {
            performHapticFeedback()
            if (fullTextToShare.isNotEmpty()) {
                val sendIntent = Intent().apply { action = Intent.ACTION_SEND; putExtra(Intent.EXTRA_TEXT, fullTextToShare); type = "text/plain" }
                startActivity(Intent.createChooser(sendIntent, "Share via"))
            }
        }

        loadHistory()
    }

    private fun performHapticFeedback() {
        if (getSharedPreferences("HapticsPrefs", Context.MODE_PRIVATE).getBoolean("hapticsEnabled", true)) {
            window.decorView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("word", tvWord.text.toString())
        outState.putString("pos", tvPos.text.toString())
        outState.putString("def", tvDefinition.text.toString())
        outState.putString("example", tvExample.text.toString())
        outState.putString("syn", tvSynonyms.text.toString())
        outState.putString("ant", tvAntonyms.text.toString())
        outState.putString("hindi", tvHindi.text.toString())
        outState.putString("odia", tvOdia.text.toString())
        outState.putString("currentWord", currentWord)
        outState.putString("currentDef", currentDef)
        outState.putString("shareText", fullTextToShare)
        outState.putInt("visibility", resultsLayout.visibility)
        outState.putInt("emptyVis", emptyStateLayout.visibility)
    }

    private fun performSearch() {
        val query = etSearch.text.toString().trim().lowercase()
        if (query.isEmpty()) {
            Toast.makeText(this, "Please enter a word", Toast.LENGTH_SHORT).show()
        } else {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(etSearch.windowToken, 0)
            searchWord(query)
        }
    }

    private fun searchWord(query: String) {
        emptyStateLayout.visibility = View.GONE 
        resultsLayout.visibility = View.GONE
        progressBar.visibility = View.VISIBLE

        thread {
            try {
                val encodedQuery = URLEncoder.encode(query, "UTF-8")
                val executor = Executors.newFixedThreadPool(5)

                val dictFuture = executor.submit<String> { fetchUrlWithRetry("https://api.dictionaryapi.dev/api/v2/entries/en/$query") }
                val synFuture = executor.submit<String> { fetchDatamuseWords(query, "rel_syn") }
                val antFuture = executor.submit<String> { fetchDatamuseWords(query, "rel_ant") }
                val hiFuture = executor.submit<String> { fetchUrlWithRetry("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=hi&dt=t&q=$encodedQuery") }
                val orFuture = executor.submit<String> { fetchUrlWithRetry("https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=or&dt=t&q=$encodedQuery") }

                val dictResponse = dictFuture.get()
                val syns = synFuture.get()
                val ants = antFuture.get()
                val hiResponse = hiFuture.get()
                val orResponse = orFuture.get()
                
                executor.shutdown()

                val dictArray = JSONArray(dictResponse)
                val firstEntry = dictArray.getJSONObject(0)
                currentWord = firstEntry.getString("word")
                val meaningsArray = firstEntry.getJSONArray("meanings")
                val firstMeaning = meaningsArray.getJSONObject(0)
                val pos = firstMeaning.getString("partOfSpeech")
                val firstDefObj = firstMeaning.getJSONArray("definitions").getJSONObject(0)
                currentDef = firstDefObj.getString("definition")
                
                var exampleText = "No example available."
                loop@ for (m in 0 until meaningsArray.length()) {
                    val meaning = meaningsArray.getJSONObject(m)
                    val defsArray = meaning.getJSONArray("definitions")
                    for (d in 0 until defsArray.length()) {
                        val def = defsArray.getJSONObject(d)
                        if (def.has("example")) { exampleText = def.getString("example"); break@loop }
                    }
                }

                val hiJsonArray = JSONArray(hiResponse)
                var hindiText = hiJsonArray.getJSONArray(0).getJSONArray(0).getString(0).trim()
                val orJsonArray = JSONArray(orResponse)
                var odiaText = orJsonArray.getJSONArray(0).getJSONArray(0).getString(0).trim()

                val cleanQuery = query.replace("[^a-zA-Z]".toRegex(), "").lowercase()
                if (hindiText.replace("[^a-zA-Z]".toRegex(), "").lowercase() == cleanQuery || hindiText.isEmpty()) hindiText = "Not available"
                if (odiaText.replace("[^a-zA-Z]".toRegex(), "").lowercase() == cleanQuery || odiaText.isEmpty()) odiaText = "Not available"

                fullTextToShare = "Word: ${currentWord.replaceFirstChar { it.uppercase() }}\nPart of Speech: $pos\nDefinition: $currentDef\nExample: $exampleText\nHindi: $hindiText\nOdia: $odiaText"

                runOnUiThread {
                    progressBar.visibility = View.GONE
                    resultsLayout.visibility = View.VISIBLE
                    tvWord.text = currentWord.replaceFirstChar { it.uppercase() }
                    tvPos.text = "Part of Speech: $pos"
                    tvDefinition.text = "Definition: $currentDef"
                    tvExample.text = "Example: $exampleText"
                    tvHindi.text = "Hindi: $hindiText"
                    tvOdia.text = "Odia: $odiaText"
                    tvSynonyms.text = "Synonyms: $syns"
                    tvAntonyms.text = "Antonyms: $ants"
                    updateHistory(query)
                    mainScrollView.post { mainScrollView.fullScroll(View.FOCUS_DOWN) }
                }

            } catch (e: Exception) {
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    resultsLayout.visibility = View.VISIBLE
                    tvWord.text = "Error"
                    tvDefinition.text = "Word not found or Network error. Please try again."
                    tvPos.text = ""
                    tvExample.text = ""
                    tvSynonyms.text = ""
                    tvAntonyms.text = ""
                    tvHindi.text = ""
                    tvOdia.text = ""
                }
            }
        }
    }

    private fun fetchDatamuseWords(query: String, relation: String): String {
        try {
            val response = fetchUrlWithRetry("https://api.datamuse.com/words?$relation=$query&max=5")
            val jsonArray = JSONArray(response)
            val wordList = mutableListOf<String>()
            for (i in 0 until jsonArray.length()) { wordList.add(jsonArray.getJSONObject(i).getString("word")) }
            return if (wordList.isNotEmpty()) wordList.joinToString(", ") else "None"
        } catch (e: Exception) { return "None" }
    }

    private fun updateHistory(searchWord: String) {
        val prefs = getSharedPreferences("HistoryPrefs", Context.MODE_PRIVATE)
        val historyList = (prefs.getString("history", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
        historyList.remove(searchWord)
        historyList.add(0, searchWord)
        if (historyList.size > 5) historyList.removeAt(historyList.size - 1)
        prefs.edit().putString("history", historyList.joinToString(",")).apply()
        loadHistory()
    }

    private fun loadHistory() {
        val prefs = getSharedPreferences("HistoryPrefs", Context.MODE_PRIVATE)
        val historyList = (prefs.getString("history", "") ?: "").split(",").filter { it.isNotEmpty() }
        chipGroupHistory.removeAllViews()
        for (word in historyList) {
            val chip = Chip(this)
            chip.text = word
            chip.isClickable = true
            chip.isCheckable = false
            chip.setOnClickListener {
                performHapticFeedback()
                etSearch.setText(word)
                performSearch()
            }
            chipGroupHistory.addView(chip)
        }
    }

    private fun fetchUrlWithRetry(urlString: String): String {
        var retries = 2 
        while (retries > 0) {
            try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.connectTimeout = 3000 
                connection.readTimeout = 3000    
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", "Mozilla/5.0")
                if (connection.responseCode == 200) {
                    return connection.inputStream.bufferedReader().use { it.readText() }
                } else {
                    throw Exception("Response code: ${connection.responseCode}")
                }
            } catch (e: Exception) {
                retries--
                if (retries == 0) throw e
                Thread.sleep(200) 
            }
        }
        return ""
    }

    private fun saveWord() {
        if (currentWord.isEmpty()) return
        val prefs = getSharedPreferences("SavedDict", Context.MODE_PRIVATE)
        val savedSet = prefs.getStringSet("words", mutableSetOf()) ?: mutableSetOf()
        val newSet = savedSet.toMutableSet()
        newSet.add("$currentWord|$currentDef")
        prefs.edit().putStringSet("words", newSet).apply()
        Toast.makeText(this, "Word Saved!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::ttsEnglish.isInitialized) { ttsEnglish.stop(); ttsEnglish.shutdown() }
        if (::ttsHindi.isInitialized) { ttsHindi.stop(); ttsHindi.shutdown() }
        if (::ttsOdia.isInitialized) { ttsOdia.stop(); ttsOdia.shutdown() }
        super.onDestroy()
    }
}